﻿namespace Snake.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}